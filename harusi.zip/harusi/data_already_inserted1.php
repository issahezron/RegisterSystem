<?php  
 $connect = mysqli_connect("localhost", "root", "", "zzz");  
 $message = '';  
 if(isset($_POST["add"]))  
 {  
      if(!empty($_POST["brand"]))  
      {  
           $sql = "  
                INSERT INTO brand (brand_name)  
                SELECT '".$_POST["brand"]."' FROM brand  
                WHERE NOT EXIST(  
                 SELECT brand_name FROM brand WHERE brand_name = '".$_POST["brand"]."'  
                ) LIMIT 1  
           ";  
           if(mysqli_query($connect, $sql))  
           {  
                $insert_id = mysqli_insert_id($connect);  
                if($insert_id != '')  
                {  
                     header("location:data_already_inserted.php?inserted=1");  
                }  
                else  
                {  
                     header("location:data_already_inserted.php?already=1");  
                }  
           }  
      }  
      else  
      {  
           header("location:data_already_inserted.php?required=1");  
      }  
 }  
 if(isset($_GET["inserted"]))  
 {  
      $message = "Code successfully matched";  
     }  
     if(isset($_GET["already"]))  
     {  
          $message = "Code already used!Contact the organizers";  
     }  
     if(isset($_GET["required"]))  
     {  
          $message = "Code Required";  
     }  
     ?>  
     <!DOCTYPE html>  
     <html>  
          <head>  
               <title>HARUSI</title>  
               <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
               <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
               <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 
               <style>
                body {
  background-color: #b76e79;
}
h2.round {
  border-left-style: 20px solid yellow;
  border-left-right: 20px solid yellow;
  border-radius: 12px;
  background-color: #f5ded2;
} 
</style>
          </head>  
          <body>  
               <br />  
              <font color="black"> <h2 align="center" class="round"><b><i>EDWIN AND JACKY NIGHT</i></b></h2></font>
               <table align="center">
                <tr>

                  <td><img src="rings.png"height="200" width="200"></td>
                  <td><div class="container" style="width:500px;">  
                    <!--<label class="text-danger">  
                    <?php  
                    if($message!= '')  
                    {  
                         echo $message;  
                    }  
                    ?> -->
                    </label>  
                    <!--<h3 align="">Verify the Code</h3>--><br />                 
                    <form method="post">  
                         <label><font color="white">Enter Code</font></label>  
                         <input type="text" name="brand" class="form-control" />  
                         <br />  
                         <input type="submit" name="add" class="btn btn-info" value="add" />  
                </form>  
           </div> </td>
           <td><img src="rings.png"height="200" width="200"></td>
         </tr></table>
         <p align="center"><img src="couple.png"height="200" width="200"></p>
       

           <br />  
      </body>  
 </html>  