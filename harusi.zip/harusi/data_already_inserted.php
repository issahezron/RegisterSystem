<?php  
 $connect = mysqli_connect("localhost", "root", "", "zzz");  

 
 $brand_name=filter_input(INPUT_POST, 'brand_name');
 
 CheckIFAlreadyAdded($connect,$brand_name);
  
 function CheckIFAlreadyAdded($connect,$brand_name){
     $query = "select * from brand where brand_name='$brand_name'";
     $run   = mysqli_query($connect,$query);
     $NumberOfRows = mysqli_num_rows($run);
     if($NumberOfRows<='0'){
         if(!empty($brand_name)){
         AddToDatabase($connect, $brand_name);
         }
     }
     elseif ($NumberOfRows >='1') {
         
          echo"<script>alert('Code already used! Please contact Organizers')</script>";
 }
 }
 
 function AddToDatabase($connect,$brand_name){
     
     $query = "insert into brand (brand_name) value('$brand_name')";
     //var_dump($query);
    $run= mysqli_query($connect,$query);
     if($run){
      echo"<script>alert('Code Verified Successfully')</script>";
     }
     }
     ?>  
     <!DOCTYPE html>  
     <html>  
          <head>  
               <title>HARUSI</title>  
               <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
               <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
               <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 
               <style>
                body {
  background-color: #b76e79;
}
h2.round {
  border-left-style: 20px solid yellow;
  border-left-right: 20px solid yellow;
  border-radius: 12px;
  background-color: #f5ded2;
} 
</style>
          </head>  
          <body>  
               <br />  
              <font color="black"> <h2 align="center" class="round"><b><i>EDWIN AND JACKY NIGHT</i></b></h2></font>
               <table align="center">
               
                <tr>

                  <td><img src="rings.png"height="200" width="200"></td>
                  <td><div class="container" style="width:500px;">  
                    <!--<label class="text-danger">  
                    <?php  
                    if($message!= '')  
                    {  
                         echo $message;  
                    }  
                    ?> -->
                    </label>  
                    <!--<h3 align="">Verify the Code</h3>--><br />                 
                    <form method="post" action="">  
                         <label><font color="white">Enter Code</font></label>  
                         <input type="text" name="brand_name" class="form-control" />  
                         <br />  
                         <input type="submit" name="add" class="btn btn-info" value="Verify" />  
                </form>  
           </div> </td>
           <td><img src="rings.png"height="200" width="200"></td>
         </tr></table>
         <p align="center"><img src="couple.png"height="200" width="200"></p>
       

           <br />
           <footer align="center"><i> System Dev. by Issa</i> </footer>   
      </body>  
 </html>  